# macOS 本地版发布说明

## v1.0.0

首个 macOS 本地版发布。

### 包含内容

- 打包后的网页程序 `app/`
- macOS 一键启动脚本 `启动mac版.command`
- Python 本地静态网页服务 `local-server-mac.py`
- macOS 使用说明

### 使用方式

1. 下载 macOS 版压缩包。
2. 解压整个文件夹。
3. 双击 `启动mac版.command`。
4. 浏览器会自动打开本地复习页面。

不要直接分享 `127.0.0.1` 链接；请分享压缩包。
