#!/usr/bin/env python3
import argparse
import functools
import mimetypes
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class LocalAppHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def guess_type(self, path):
        suffix = Path(path).suffix.lower()
        custom_types = {
            ".html": "text/html; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".webmanifest": "application/manifest+json; charset=utf-8",
            ".svg": "image/svg+xml",
        }
        return custom_types.get(suffix) or mimetypes.guess_type(path)[0] or "application/octet-stream"

    def log_message(self, format, *args):
        return


def main():
    parser = argparse.ArgumentParser(description="Run the Medical Humanities English local app.")
    parser.add_argument("--root", required=True, help="Path to the built app folder.")
    parser.add_argument("--port", type=int, default=5179, help="Local server port.")
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"App folder does not exist: {root}")

    if not (root / "index.html").is_file():
        raise SystemExit(f"Missing file: {root / 'index.html'}")

    handler = functools.partial(LocalAppHandler, directory=str(root))
    address = ("127.0.0.1", args.port)

    try:
        server = ThreadingHTTPServer(address, handler)
    except OSError as exc:
        raise SystemExit(f"Cannot start server on http://127.0.0.1:{args.port}/\n{exc}") from exc

    print("Medical Humanities English Review")
    print(f"Serving: {root}")
    print(f"Open: http://127.0.0.1:{args.port}/?v=macos")
    print("Keep this Terminal window open while using the page.")
    print("Press Control+C to stop the local server.")
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print()
        print("Local server stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
