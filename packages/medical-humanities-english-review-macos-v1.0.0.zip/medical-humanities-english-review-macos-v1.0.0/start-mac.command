#!/bin/zsh
set -u

cd "$(dirname "$0")" || exit 1

APP_DIR="$PWD/app"
SERVER_SCRIPT="$PWD/local-server-mac.py"
PORT_START=5179
PORT_END=5199

clear
echo "医学人文英语复习小程序 macOS 本地版"
echo

if [ ! -f "$APP_DIR/index.html" ]; then
  echo "缺少文件："
  echo "$APP_DIR/index.html"
  echo "请确认 app 文件夹和本启动文件在同一个目录。"
  echo
  printf "按回车关闭窗口..."
  read -r _
  exit 1
fi

if [ ! -f "$SERVER_SCRIPT" ]; then
  echo "缺少文件："
  echo "$SERVER_SCRIPT"
  echo "请确认 local-server-mac.py 和本启动文件在同一个目录。"
  echo
  printf "按回车关闭窗口..."
  read -r _
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "没有找到 python3。"
  echo "请先安装 Python 3，或安装 Xcode Command Line Tools 后再运行。"
  echo
  printf "按回车关闭窗口..."
  read -r _
  exit 1
fi

PORT="$(python3 - "$PORT_START" "$PORT_END" <<'PY'
import socket
import sys

start = int(sys.argv[1])
end = int(sys.argv[2])

for port in range(start, end + 1):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("127.0.0.1", port))
        except OSError:
            continue
        print(port)
        break
PY
)"

if [ -z "$PORT" ]; then
  echo "端口 $PORT_START 到 $PORT_END 都被占用。"
  echo "请关闭旧的本地服务窗口后重试。"
  echo
  printf "按回车关闭窗口..."
  read -r _
  exit 1
fi

URL="http://127.0.0.1:${PORT}/?v=macos"

echo "本地目录：$APP_DIR"
echo "访问地址：$URL"
echo
echo "正在启动本地网页服务..."
echo "使用期间不要关闭这个 Terminal 窗口。"
echo

(sleep 1; open "$URL" >/dev/null 2>&1) &
python3 "$SERVER_SCRIPT" --root "$APP_DIR" --port "$PORT"
STATUS=$?

echo
echo "本地服务已停止。"
printf "按回车关闭窗口..."
read -r _
exit "$STATUS"
