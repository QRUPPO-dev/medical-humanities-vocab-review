@echo off
setlocal EnableExtensions

set "APP_DIR=%~dp0app"
set "SERVER_SCRIPT=%~dp0local-server.ps1"
set "PORT=5179"
set "URL=http://127.0.0.1:%PORT%/?v=windows"

if not exist "%APP_DIR%\index.html" (
  echo Missing file:
  echo "%APP_DIR%\index.html"
  echo Keep the app folder next to this bat file.
  pause
  exit /b 1
)

if not exist "%SERVER_SCRIPT%" (
  echo Missing file:
  echo "%SERVER_SCRIPT%"
  echo Keep local-server.ps1 next to this bat file.
  pause
  exit /b 1
)

where powershell >nul 2>nul
if errorlevel 1 (
  echo Windows PowerShell was not found.
  echo Please use a normal Windows 10 or Windows 11 computer.
  pause
  exit /b 1
)

echo Medical Humanities English Review
echo Local folder: "%APP_DIR%"
echo URL: %URL%
echo.
echo Starting local web server...
echo Keep the server window open while using the page.
echo.

start "Medical English Local Server" powershell -NoProfile -ExecutionPolicy Bypass -File "%SERVER_SCRIPT%" -Root "%APP_DIR%" -Port %PORT%
ping -n 3 127.0.0.1 >nul
start "" "%URL%"

echo.
echo The page should be open in your browser now.
echo If it still says connection refused, close all server windows and run this bat again.
echo.
pause
